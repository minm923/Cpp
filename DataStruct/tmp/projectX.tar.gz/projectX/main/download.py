# -*- encoding: utf-8 -*-

import os
import ccxt
import time
import pandas as pd

def fetchOHLCV(exchange, dataFile, interval_ts,  symbol, timeframe, current_ts):
    past_ts = 1000 * 60 * 60 * 24 * 365 * 10
    current_ts = round(time.time() * 1000)
    start_ts = float(current_ts - past_ts)
    start_index = 0

    try:
        lastKLine= pd.read_hdf(dataFile, key='all_data', start=-1) # read last row
    except FileNotFoundError as e:
        print(e)
    except Exception as e:
        print(e)
        os.remove(dataFile)
    else:
        start_ts = lastKLine.iat[-1, 0] + interval_ts
        start_index = lastKLine.index[-1] + 1


    while start_ts <= current_ts:
        try:
            print(start_ts)
            print(start_index)
            candleData = exchange.fetch_ohlcv(symbol, timeframe=timeframe, since=start_ts, limit=1000)
            if 0 != len(candleData):
                df = pd.DataFrame(candleData, dtype=float)
                df.index = [i + start_index for i in df.index.tolist()]
                df.to_hdf(dataFile, key='all_data', mode='a', append=bool)
                start_ts = df.iat[-1, 0] + interval_ts
                start_index = df.index[-1] + 1
        except ccxt.BaseError as e:
            print(e)
        except Exception as e:
            print(e)
        finally:
            time.sleep(1)
