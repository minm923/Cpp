#! -*- encoding: utf-8 -*-
import json
import requests
import datetime

def send_dingding_mgs(content, robot_id='55adbb2d03e3f77b00c11e83156b9ee19d3280d37c676c21e538cd7ec5f4c6d2'):
    try:
        msg = {"msgtype":"text","text":{"content": content + '\n' + datetime.datetime.now().strftime("%m-%d %H:%M:%S")}}
        Headers = {"Content-Type":"application/json;charset=utf-8"}
        url = 'https://oapi.dingtalk.com/robot/send?access_token=' + robot_id
        body = json.dumps(msg)
        requests.post(url, data=body, headers=Headers)
    except Exception as err:
        print("send fail", err)

