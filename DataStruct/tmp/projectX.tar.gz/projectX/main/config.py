# -*- coding: utf-8 -*-

import configparser

class ConfigLoad(object):
    def __init__(self, config_file):
        config = configparser.ConfigParser()
        try:
            with open(config_file, 'r') as f:
                config.readfp(f)
                self.__config_dict = dict(item for item in config.items('x'))
        except IOError:
            raise ConfigError('The config file not found')

    def getConfigValue(self, key):
        """ getConfigValue by key
        """
        return self.__config_dict[key]
