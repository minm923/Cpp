# -*- encoding: utf-8 -*-

import os
import math
import json
import time
import ccxt
import pandas as pd

from email.mime.text import MIMEText
from datetime import datetime, timedelta
from smtplib import SMTP

import log
import trade
import config
import logging
import download
import strategy
import dingding

# PATH
cur_dir = os.path.dirname(os.path.abspath(__file__))
iniFile = cur_dir + "/../conf/x.ini"
c = config.ConfigLoad(iniFile)

# CONF
apiKey = c.getConfigValue("apikey")
secret = c.getConfigValue("secret")
symbol = c.getConfigValue("symbol")
timeframe = c.getConfigValue("timeframe")
interval_ts = int(c.getConfigValue("interval_ts"))
n = int(c.getConfigValue("n"))
m = int(c.getConfigValue("m"))
leverage = 2
logFile = cur_dir + "/../log/x"

# LOG
log.init_log(logFile)

# exchange
exchange = ccxt.bitfinex()
exchange.apiKey = apiKey
exchange.secret = secret

# DATA
dataFile = cur_dir + "/../data/BITFINEX_EOS_USD_15m.h5"
current_ts = round(time.time() * 1000)
download.fetchOHLCV(exchange, dataFile, interval_ts, symbol, timeframe, current_ts)

while True:
    current_ts = round(time.time() * 1000)
    x = int(current_ts / interval_ts)
    proc_time = (x+1) * interval_ts
    logging.info("proc_time {}".format(proc_time))
    logStr = ""

    while round(time.time() * 1000) < proc_time:
        time.sleep(1)

    download.fetchOHLCV(exchange,  dataFile, interval_ts, symbol, timeframe, proc_time)

    df = pd.read_hdf(dataFile, key='all_data')
    df[0] = df[0].astype(int)
    df.rename(columns={0: 'MTS', 1: 'open', 2: 'high', 3: 'low', 4: 'close', 5: 'volume'}, inplace=True)
    df = strategy.signal_bolling(df, [n, m])
    signal = df.iloc[-1]['signal']

    dingding.send_dingding_mgs('trade signal :{}'.format(str(signal)))
    logging.info('trade signal :{}'.format(str(signal)))

    if math.isnan(signal):
        continue

    eos_amount = 0
    positions = trade.fetch_position(exchange)
    for pos in positions:
        if 'eosusd' == pos['symbol']:
            eos_amount = float(pos['amount'])
    
    prices = trade.fetch_ticker(exchange, symbol)

    if 0 == signal and 0 != eos_amount:
        if eos_amount > 0:
            trade.place_order(exchange, 'limit', 'sell', symbol, prices['bid'] * 0.98, eos_amount)
            logStr = "place order limit sell {} price : {}, amount : {}".format(symbol, prices['bid'] * 0.98, eos_amount)
        else:
            trade.place_order(exchange, 'limit', 'buy', symbol, prices['ask'] * 1.02, eos_amount)
            logStr = "place order limit buy {} price : {}, amount : {}".format(symbol, prices['ask'] * 1.02, eos_amount)

    if 1 == signal:
        if eos_amount < 0:
            trade.place_order(exchange, 'limit', 'buy', symbol, prices['ask'] * 1.02, eos_amount)
            logStr = "close pos, place order limit buy {} price : {}, amount : {} ;".format(symbol, prices['ask'] * 1.02, eos_amount)
            time.sleep(2)

        margin = trade.fetch_balance(exchange)
        prices = trade.fetch_ticker(exchange, symbol)
        price = prices['ask'] * 1.02
        buy_amount = margin["USD"]["free"] * leverage / price
        trade.place_order(exchange, 'limit', 'buy', symbol, price, buy_amount)
        logStr += " place order limit buy {} price : {}, amount : {}".format(symbol, price, buy_amount)

    if -1 == signal:
        if eos_amount > 0:
            trade.place_order(exchange, 'limit', 'sell', symbol, prices['bid'] * 0.98, eos_amount)
            logStr = "close pos, place order limit sell {} price : {}, amount : {} ;".format(symbol, prices['bid'] * 0.98, eos_amount)
            time.sleep(2)

        margin = trade.fetch_balance(exchange)
        prices = trade.fetch_ticker(exchange, symbol)
        price = prices['bid'] * 0.98
        sell_amount = margin["USD"]["free"] * leverage / price
        trade.place_order(exchange, 'limit', 'sell', symbol, price, sell_amount)
        logStr += " place order limit sell {} price : {}, amount : {}".format(symbol, price, sell_amount)

    logging.info(logStr)
    dingding.send_dingding_mgs(logStr)
