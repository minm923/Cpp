# -*- encoding: utf-8 -*-

import os
import ccxt
import time
import json
import logging

def place_order(exchange, order_type, buy_or_sell, symbol, price, amount):
    for i in range(5):
        try:
            # 限价单
            if order_type == 'limit':
                # 买
                if buy_or_sell == 'buy':
                    order_info = exchange.create_limit_buy_order(symbol, amount, price, {'type': 'limit'})  # 买单
                # 卖
                elif buy_or_sell == 'sell':
                    order_info = exchange.create_limit_sell_order(symbol, amount, price, {'type': 'limit'})  # 卖单
            # 市价单
            elif order_type == 'market':
                # 买
                if buy_or_sell == 'buy':
                    order_info = exchange.create_market_buy_order(symbol=symbol, amount=amount)  # 买单
                # 卖
                elif buy_or_sell == 'sell':
                    order_info = exchange.create_market_sell_order(symbol=symbol, amount=amount)  # 卖单
            else:
                pass

            logging.info('place order success {} {} {} {} {}'.format(order_type, buy_or_sell, symbol, price, amount))
            logging.info('order info ：{}'.format(json.dumps(order_info)))
            return order_info

        except Exception as e:
            logging.exception(e)
            time.sleep(1)

    logging.info('too many error. exit')
    exit()

def fetch_balance(exchange):
    for i in range(5):
        try:
            balance_margin= exchange.fetch_balance({'type':'trading'})
            return balance_margin
        except Exception as e:
            logging.exception(e)
            time.sleep(1)
    logging.info('too many error. exit')
    exit()


def fetch_position(exchange):
    for i in range(5):
        try:
            positions = exchange.private_post_positions()
            return positions
        except Exception as e:
            logging.info(e)
            time.sleep(1)
    logging.info('too many error. exit')
    exit()

def fetch_ticker(exchange, symbol):
    for i in range(5):
        try:
            price = exchange.fetch_ticker(symbol)
            return price
        except Exception as e:
            logging.info(e)
            time.sleep(1)
    logging.info('too many error. exit')
    exit()
